-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 13, 2024 at 10:07 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `canteenms`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Drinks'),
(2, 'Snacks'),
(3, 'Snacksss'),
(4, 'Drinksss'),
(5, 'Junkfood');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `market_price` decimal(10,2) NOT NULL,
  `selling_price` decimal(10,2) NOT NULL,
  `category` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `quantity`, `image`, `expiry_date`, `market_price`, `selling_price`, `category`) VALUES
(45, 'Zesto', 41, 'zest-o-juice-drink.jpg', '2024-10-05', 1.00, 8.00, 'Drinks'),
(46, 'FudgeBar', 32, 'fudgee-barr-chocolate.jpg', '2024-10-11', 1.00, 6.00, 'Snacks'),
(47, 'Piattos', 0, '102064891_1024x.jpg', '2024-10-11', 1.00, 5.00, 'Snacks'),
(48, 'asdsdsd', 0, '102064891_1024x.jpg', '2024-10-11', 1.00, 4.00, 'Snacksss'),
(49, 'FudgeBar1111', 0, 'fudgee-barr-chocolate.jpg', '2024-10-12', 1.00, 2.00, 'Snacksss'),
(50, 'FudgeBaraaaaa', 4, 'zest-o-juice-drink.jpg', '2024-10-12', 1.00, 2.00, 'Drinksss'),
(51, 'Zesto09', 0, 'Screen-Shot-2021-10-13-at-11.07.12-AM.png', '2024-10-12', 1.00, 5.00, 'Junkfood'),
(52, 'Peanut', 0, 'e0ec1c4e-c857-4c62-b17e-70624a610587.jpeg', '2024-10-17', 50.00, 100.00, 'Drinks');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity_sold` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `sale_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `product_id`, `quantity_sold`, `total`, `sale_date`) VALUES
(1, 45, 1, 8.00, '2024-10-13 13:37:22'),
(2, 46, 1, 6.00, '2024-10-13 13:37:22'),
(3, 47, 2, 10.00, '2024-10-13 13:37:22'),
(4, 48, 1, 4.00, '2024-10-13 13:37:22'),
(5, 49, 1, 2.00, '2024-10-13 13:37:22'),
(6, 51, 1, 5.00, '2024-10-13 13:37:22'),
(7, 50, 1, 2.00, '2024-10-13 13:37:22'),
(8, 45, 1, 8.00, '2024-10-13 13:38:42'),
(9, 46, 1, 6.00, '2024-10-13 13:38:42'),
(10, 47, 1, 5.00, '2024-10-13 13:38:42'),
(11, 48, 1, 4.00, '2024-10-13 13:38:42'),
(12, 49, 1, 2.00, '2024-10-13 13:38:42'),
(13, 51, 1, 5.00, '2024-10-13 13:38:42'),
(14, 50, 1, 2.00, '2024-10-13 13:38:42'),
(15, 45, 1, 8.00, '2024-10-13 13:41:41'),
(16, 46, 1, 6.00, '2024-10-13 13:41:41'),
(17, 51, 1, 5.00, '2024-10-13 13:41:53'),
(18, 50, 2, 4.00, '2024-10-13 13:41:53'),
(19, 49, 1, 2.00, '2024-10-13 13:41:53'),
(20, 48, 1, 4.00, '2024-10-13 13:41:53'),
(21, 47, 1, 5.00, '2024-10-13 13:41:53'),
(22, 46, 1, 6.00, '2024-10-13 13:41:53'),
(23, 45, 1, 8.00, '2024-10-13 13:41:53'),
(24, 49, 1, 2.00, '2024-10-13 13:51:49'),
(25, 48, 1, 4.00, '2024-10-13 13:51:49'),
(26, 47, 1, 5.00, '2024-10-13 13:51:49'),
(27, 46, 1, 6.00, '2024-10-13 13:51:49'),
(28, 45, 1, 8.00, '2024-10-13 13:51:49'),
(29, 50, 1, 2.00, '2024-10-13 13:51:49'),
(30, 51, 1, 5.00, '2024-10-13 13:51:49'),
(31, 47, 1, 5.00, '2024-10-13 13:52:24'),
(32, 46, 1, 6.00, '2024-10-13 13:52:24'),
(33, 45, 1, 8.00, '2024-10-13 13:52:24'),
(34, 48, 1, 4.00, '2024-10-13 13:52:24'),
(35, 49, 1, 2.00, '2024-10-13 13:52:24'),
(36, 51, 1, 5.00, '2024-10-13 13:52:24'),
(37, 50, 1, 2.00, '2024-10-13 13:52:24'),
(38, 52, 50, 5000.00, '2024-10-13 15:12:27'),
(39, 45, 1, 8.00, '2024-10-13 15:12:27'),
(40, 47, 5, 25.00, '2024-10-13 15:38:55'),
(41, 49, 5, 10.00, '2024-10-13 15:39:19'),
(42, 45, 1, 8.00, '2024-10-13 19:40:45'),
(43, 48, 1, 4.00, '2024-10-13 19:40:45'),
(44, 46, 1, 6.00, '2024-10-13 19:40:45'),
(45, 45, 1, 8.00, '2024-10-13 21:09:10'),
(46, 46, 1, 6.00, '2024-10-13 21:09:10'),
(47, 48, 1, 4.00, '2024-10-13 21:09:27'),
(48, 45, 1, 8.00, '2024-10-13 21:09:27'),
(49, 45, 1, 8.00, '2024-10-13 21:10:49'),
(50, 48, 1, 4.00, '2024-10-13 21:10:49'),
(51, 45, 1, 8.00, '2024-10-13 21:12:12'),
(52, 46, 1, 6.00, '2024-10-13 21:12:12'),
(53, 46, 1, 6.00, '2024-10-13 22:04:52'),
(54, 45, 1, 8.00, '2024-10-13 22:04:52'),
(55, 48, 1, 4.00, '2024-10-13 22:04:52'),
(56, 46, 1, 6.00, '2024-10-13 22:05:09'),
(57, 45, 1, 8.00, '2024-10-13 22:05:09'),
(58, 48, 1, 4.00, '2024-10-13 22:05:09'),
(59, 51, 5, 25.00, '2024-10-13 22:05:39'),
(60, 46, 12, 72.00, '2024-10-13 22:05:39');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `student_id` varchar(50) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(250) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `rfid_code` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `balance` decimal(10,2) NOT NULL DEFAULT 0.00,
  `user_type` enum('user','cstaff','cmanager','cashier','superadmin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `student_id`, `first_name`, `middle_name`, `last_name`, `email`, `rfid_code`, `password`, `balance`, `user_type`) VALUES
(5, '52552021', 'James Andrew', 'Adriano', 'Beley', 'jemusubeley@gmail.com', '0013389623', '$2y$10$S57d2QOZ5cRPphyzW7eheeubD4.we1bPOPkx7Ebj031Zd0wQ.O8Zm', 3.00, 'user'),
(6, '52552021', 'James Andrew', 'Adriano', 'Beley', 'beley@gmail.com', '123456789', '$2y$10$sARfuV6e6HzPG.wkR9U34.1EIXQXb9vTNq7R.Grn86mtLor8LjHya', 0.00, 'user'),
(7, '46182021', 'Grant Mikhail', 'Cayaba', 'Dela Cruz', 'grantmikhail@gmail.com', '0012245507', '$2y$10$.VxmdHAd2G0XI0Vvfu918.A//FxmndCHnlQzgYmYpj1aUdDBsYYSm', 200.00, 'user'),
(8, '5042017', 'Abraham', 'Ducha', 'Flores', 'abrahamflores@gmail.com', '0011793621', '$2y$10$U2udgWJ7wdvwyjPKmhQAF.jx4zvNInpAeU013M1Rtzl5dJkEuxZxW', 200.00, 'user'),
(9, '0000', 'Super', 'Admin', 'To', 'superadmin@gmail.com', 'sadmin', '$2y$10$grGkQDeAQUraCd2i.sl1ue4jhtUw1KS31pCa87ke01kBlQ4RaN0Qa', 0.00, 'superadmin'),
(10, '0001', 'Canteen', 'Staff', 'To', 'cstaff@gmail.com', 'cstaff', '$2y$10$EgXp3VEGYZtFT96d0IHwQOLSf52nTZXypqFoX46YnLLfcplkuk/qO', 0.00, 'cstaff'),
(11, '0002', 'Cashier', 'Po', 'To', 'cashierhcc@gmail.com', 'cashierhcc', '$2y$10$Tbr/vQ3s2gZK5vVgdTXHF.UxFwxdGga/FaVzvQZiKx1If1b73.oCy', 0.00, 'cashier'),
(12, '0003', 'Canteen', 'Manager', 'To', 'cmanager@gmail.com', 'cmanager', '$2y$10$2DeXlrLHbHG4lJQQPbndu.rTiAP23qF.oXjOXicSEPekEv6I.DQ92', 0.00, 'cmanager');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','cashier','cstaff','cadmin','student') DEFAULT 'cstaff',
  `user_type` enum('users','cstaff','cmanager','cashier','superadmin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `user_type`) VALUES
(3, 'cstaff', '$2y$10$skYXyxo69sUe1Wa5xNQ1jeGlyBbnwOBIBR0rp/w8yfQqu.I5fqM.W', 'cstaff', 'users'),
(4, 'cadmin', '$2y$10$TZv4A3AdOGTzfJhkuT.AguKb8HfZFZcLQ18zEUoE.OyXMXYIt3J1W', 'cadmin', 'users');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `rfid_code` (`rfid_code`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
